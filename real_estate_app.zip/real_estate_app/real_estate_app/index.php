<?php require 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
<title>Real Estate App</title>
<style>
body { font-family: Arial; background: linear-gradient(135deg,#1e3a8a,#3b82f6); margin:0; padding:20px; color:#333;}
.container { max-width:900px; margin:auto;}
.card { background:white; padding:20px; border-radius:12px; margin-bottom:20px; box-shadow:0 4px 10px rgba(0,0,0,0.2);}
h1 { color:white; text-align:center;}
h2 { color:#1e3a8a;}
input, select { width:100%; padding:10px; margin:8px 0; border-radius:6px; border:1px solid #ccc; box-sizing:border-box;}
button { padding:10px; border:none; border-radius:6px; background:#1e3a8a; color:white; cursor:pointer;}
button:hover { background:#3b82f6;}
.success { color:green; font-weight:bold;}
.error { color:red; font-weight:bold;}
.notif { background:#eef2ff; border-left:4px solid #1e3a8a; padding:10px 14px; margin:6px 0; border-radius:6px; font-size:14px;}
.notif small { color:#888;}
.feedback-item { background:#f0fdf4; border-left:4px solid #22c55e; padding:10px 14px; margin:6px 0; border-radius:6px; font-size:14px;}
.badge { display:inline-block; padding:2px 8px; border-radius:10px; font-size:12px; font-weight:bold; color:white;}
.badge-high { background:#ef4444;}
.badge-medium { background:#f59e0b;}
.badge-low { background:#22c55e;}
</style>
</head>
<body>

<div class="container">
<h1>🏡 Real Estate Management</h1>

<?php
// Fetch existing data for dropdowns
$allPlots = $pdo->query("SELECT * FROM plots")->fetchAll();
$allClients = $pdo->query("SELECT * FROM clients")->fetchAll();
$availablePlots = array_filter($allPlots, fn($p) => $p['status'] !== 'reserved');
$allViewings = $pdo->query("SELECT v.*, p.plot_number, c.name as client_name FROM viewing v JOIN plots p ON v.plot_id=p.plot_id JOIN clients c ON v.client_id=c.client_id ORDER BY v.viewing_date DESC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['add_client'])) {
        try {
            $stmt = $pdo->prepare("INSERT INTO clients (name, phone, interest_type) VALUES (?, ?, ?)");
            $stmt->execute([$_POST['name'], $_POST['phone'], $_POST['interest']]);
            echo "<p class='success'>Client added successfully!</p>";
            // Refresh client list after adding
            $allClients = $pdo->query("SELECT * FROM clients")->fetchAll();
        } catch (PDOException $e) {
            echo "<p class='error'>Error adding client: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }

    if (isset($_POST['book_viewing'])) {
        try {
            $stmt = $pdo->prepare("INSERT INTO viewing (plot_id, client_id, agent_id, viewing_date) VALUES (?, ?, 1, ?)");
            $stmt->execute([$_POST['plot_id'], $_POST['client_id'], $_POST['date']]);
            echo "<p class='success'>Viewing booked!</p>";
            // Auto-generate notification
            $plotName = '';
            foreach ($allPlots as $pl) { if ($pl['plot_id'] == $_POST['plot_id']) $plotName = $pl['plot_number']; }
            $nStmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (1, ?)");
            $nStmt->execute(["New viewing scheduled for Plot $plotName on {$_POST['date']}"]);
            // Refresh viewings
            $allViewings = $pdo->query("SELECT v.*, p.plot_number, c.name as client_name FROM viewing v JOIN plots p ON v.plot_id=p.plot_id JOIN clients c ON v.client_id=c.client_id ORDER BY v.viewing_date DESC")->fetchAll();
        } catch (PDOException $e) {
            echo "<p class='error'>Error booking viewing: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }

    if (isset($_POST['reserve_plot'])) {
        try {
            $stmt = $pdo->prepare("INSERT INTO reservation (plot_id, client_id, agent_id, deposit_amount) VALUES (?, ?, 1, ?)");
            $stmt->execute([$_POST['plot_id'], $_POST['client_id'], $_POST['amount']]);

            $pdo->prepare("UPDATE plots SET status='reserved' WHERE plot_id=?")->execute([$_POST['plot_id']]);

            echo "<p class='success'>Plot reserved!</p>";
            // Auto-generate notification
            $plotName = '';
            foreach ($allPlots as $pl) { if ($pl['plot_id'] == $_POST['plot_id']) $plotName = $pl['plot_number']; }
            $nStmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (1, ?)");
            $nStmt->execute(["Plot $plotName has been reserved with deposit of {$_POST['amount']}"]);
            // Refresh plots after reservation
            $allPlots = $pdo->query("SELECT * FROM plots")->fetchAll();
            $availablePlots = array_filter($allPlots, fn($p) => $p['status'] !== 'reserved');
        } catch (PDOException $e) {
            echo "<p class='error'>Error reserving plot: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }

    if (isset($_POST['add_feedback'])) {
        try {
            $stmt = $pdo->prepare("INSERT INTO feedback (viewing_id, comments, interest_level) VALUES (?, ?, ?)");
            $stmt->execute([$_POST['viewing_id'], $_POST['comments'], $_POST['interest_level']]);
            echo "<p class='success'>Feedback submitted!</p>";
            // Auto-generate notification
            $nStmt = $pdo->prepare("INSERT INTO notifications (user_id, message) VALUES (1, ?)");
            $nStmt->execute(["New feedback submitted for viewing #{$_POST['viewing_id']} - Interest: {$_POST['interest_level']}"]);
        } catch (PDOException $e) {
            echo "<p class='error'>Error submitting feedback: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }
}
?>

<div class="card">
<h2>Register Client</h2>
<form method="POST">
<input type="text" name="name" placeholder="Client Name" required>
<input type="text" name="phone" placeholder="Phone" required>
<input type="text" name="interest" placeholder="Interest">
<button name="add_client">Add Client</button>
</form>
</div>

<div class="card">
<h2>Schedule Viewing</h2>
<form method="POST">
<select name="plot_id" required>
    <option value="">-- Select Plot --</option>
    <?php foreach ($allPlots as $p): ?>
        <option value="<?= $p['plot_id'] ?>">Plot <?= htmlspecialchars($p['plot_number']) ?> (<?= htmlspecialchars($p['status']) ?>)</option>
    <?php endforeach; ?>
</select>
<select name="client_id" required>
    <option value="">-- Select Client --</option>
    <?php foreach ($allClients as $c): ?>
        <option value="<?= $c['client_id'] ?>"><?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['phone']) ?>)</option>
    <?php endforeach; ?>
</select>
<input type="date" name="date" required>
<button name="book_viewing">Schedule</button>
</form>
</div>

<div class="card">
<h2>Reserve Plot</h2>
<form method="POST">
<select name="plot_id" required>
    <option value="">-- Select Available Plot --</option>
    <?php foreach ($availablePlots as $p): ?>
        <option value="<?= $p['plot_id'] ?>">Plot <?= htmlspecialchars($p['plot_number']) ?></option>
    <?php endforeach; ?>
</select>
<select name="client_id" required>
    <option value="">-- Select Client --</option>
    <?php foreach ($allClients as $c): ?>
        <option value="<?= $c['client_id'] ?>"><?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['phone']) ?>)</option>
    <?php endforeach; ?>
</select>
<input type="number" step="0.01" name="amount" placeholder="Deposit Amount" required>
<button name="reserve_plot">Reserve</button>
</form>
</div>

<div class="card">
<h2>Available Plots</h2>
<?php
foreach ($allPlots as $p) {
    $statusIcon = $p['status'] === 'available' ? '🟢' : ($p['status'] === 'reserved' ? '🟡' : '🔴');
    echo "<p>$statusIcon Plot {$p['plot_number']} - {$p['location']} - UGX " . number_format($p['price']) . " - Status: {$p['status']}</p>";
}
if (empty($allPlots)) {
    echo "<p>No plots found. Please add plots to the database.</p>";
}
?>
</div>

<div class="card">
<h2>📝 Viewing Feedback</h2>
<form method="POST">
<select name="viewing_id" required>
    <option value="">-- Select Viewing --</option>
    <?php foreach ($allViewings as $v): ?>
        <option value="<?= $v['viewing_id'] ?>">
            Plot <?= htmlspecialchars($v['plot_number']) ?> - <?= htmlspecialchars($v['client_name']) ?> (<?= $v['viewing_date'] ?>)
        </option>
    <?php endforeach; ?>
</select>
<select name="interest_level" required>
    <option value="">-- Interest Level --</option>
    <option value="high">🔴 High Interest</option>
    <option value="medium">🟡 Medium Interest</option>
    <option value="low">🟢 Low Interest</option>
</select>
<textarea name="comments" placeholder="Comments about the viewing..." style="width:100%; padding:10px; margin:8px 0; border-radius:6px; border:1px solid #ccc; box-sizing:border-box; min-height:80px; font-family:Arial;" required></textarea>
<button name="add_feedback">Submit Feedback</button>
</form>
</div>

<div class="card">
<h2>📋 Feedback History</h2>
<?php
$feedbacks = $pdo->query("SELECT f.*, v.viewing_date, p.plot_number, c.name as client_name FROM feedback f JOIN viewing v ON f.viewing_id=v.viewing_id JOIN plots p ON v.plot_id=p.plot_id JOIN clients c ON v.client_id=c.client_id ORDER BY f.feedback_id DESC")->fetchAll();
if (!empty($feedbacks)) {
    foreach ($feedbacks as $fb) {
        $badgeClass = 'badge-' . $fb['interest_level'];
        echo "<div class='feedback-item'>";
        echo "<strong>Plot {$fb['plot_number']}</strong> — {$fb['client_name']} ({$fb['viewing_date']}) ";
        echo "<span class='badge $badgeClass'>" . ucfirst($fb['interest_level']) . "</span>";
        echo "<br><em>" . htmlspecialchars($fb['comments']) . "</em>";
        echo "</div>";
    }
} else {
    echo "<p>No feedback submitted yet.</p>";
}
?>
</div>

<div class="card">
<h2>🔔 Notifications</h2>
<?php
$notifications = $pdo->query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 20")->fetchAll();
if (!empty($notifications)) {
    foreach ($notifications as $n) {
        echo "<div class='notif'>";
        echo htmlspecialchars($n['message']);
        echo " <small>" . $n['created_at'] . "</small>";
        echo "</div>";
    }
} else {
    echo "<p>No notifications yet.</p>";
}
?>
</div>

</div>
</body>
</html>
