-- ============================================
-- Real Estate App - Database Schema
-- Server: MariaDB 10.4.32
-- Database: real_estate
-- ============================================

CREATE DATABASE IF NOT EXISTS `real_estate` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `real_estate`;

-- -------------------------------------------
-- Table: users
-- Agents and admins who manage the platform
-- -------------------------------------------
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `role` enum('admin','agent') DEFAULT 'agent',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- Table: clients
-- Prospective buyers/renters
-- -------------------------------------------
CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `interest_type` varchar(100) DEFAULT NULL,
  `date_registered` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- Table: plots
-- Real estate plots/properties for sale
-- -------------------------------------------
CREATE TABLE `plots` (
  `plot_id` int(11) NOT NULL AUTO_INCREMENT,
  `plot_number` varchar(50) NOT NULL,
  `location` varchar(100) DEFAULT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `status` enum('available','reserved','sold') DEFAULT 'available',
  PRIMARY KEY (`plot_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- Table: viewing
-- Scheduled property viewings
-- -------------------------------------------
CREATE TABLE `viewing` (
  `viewing_id` int(11) NOT NULL AUTO_INCREMENT,
  `plot_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `viewing_date` date DEFAULT NULL,
  `viewing_time` time DEFAULT NULL,
  `status` enum('scheduled','completed','cancelled') DEFAULT 'scheduled',
  PRIMARY KEY (`viewing_id`),
  KEY `client_id` (`client_id`),
  KEY `plot_id` (`plot_id`),
  KEY `agent_id` (`agent_id`),
  CONSTRAINT `viewing_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`),
  CONSTRAINT `viewing_ibfk_2` FOREIGN KEY (`plot_id`) REFERENCES `plots` (`plot_id`),
  CONSTRAINT `viewing_ibfk_3` FOREIGN KEY (`agent_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- Table: reservation
-- Plot reservations with deposit tracking
-- -------------------------------------------
CREATE TABLE `reservation` (
  `reservation_id` int(11) NOT NULL AUTO_INCREMENT,
  `plot_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `deposit_amount` decimal(15,2) DEFAULT NULL,
  `status` enum('reserved','not reserved') DEFAULT 'reserved',
  `reservation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`reservation_id`),
  KEY `plot_id` (`plot_id`),
  KEY `client_id` (`client_id`),
  KEY `agent_id` (`agent_id`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`plot_id`) REFERENCES `plots` (`plot_id`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`),
  CONSTRAINT `reservation_ibfk_3` FOREIGN KEY (`agent_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- Table: feedback
-- Post-viewing feedback with interest level
-- -------------------------------------------
CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `viewing_id` int(11) NOT NULL,
  `comments` text DEFAULT NULL,
  `interest_level` enum('high','medium','low') DEFAULT NULL,
  PRIMARY KEY (`feedback_id`),
  KEY `viewing_id` (`viewing_id`),
  CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`viewing_id`) REFERENCES `viewing` (`viewing_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- Table: notifications
-- System notifications for user actions
-- -------------------------------------------
CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`notification_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- Sample Data: Default agent user
-- -------------------------------------------
INSERT INTO `users` (`username`, `role`) VALUES ('Admin Agent', 'agent');

-- -------------------------------------------
-- Sample Data: Plots
-- -------------------------------------------
INSERT INTO `plots` (`plot_number`, `location`, `price`, `status`) VALUES
('P001', 'Kampala - Ntinda', 25000000.00, 'available'),
('P002', 'Kampala - Kira', 18000000.00, 'available'),
('P003', 'Wakiso - Entebbe Road', 35000000.00, 'available'),
('P004', 'Mukono Town', 12000000.00, 'available'),
('P005', 'Jinja - Bugembe', 8000000.00, 'available');
